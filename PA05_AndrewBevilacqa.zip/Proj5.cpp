#include "LLRBT.h"
#include "LLRBT.cpp"
int genRand(const int min, const int max);
int main()
{
	LeftLeaningRBTree<int> LLRBT_a;
	int delElm=0,insElm=0;
	cout<<"Inserting 10 random integers between 1 and 100."<<endl;
	for(int i = 0;i <=9;i++)
	{
		insElm = genRand(1,100);
		LLRBT_a.insert(insElm);
		//cout<<"TEST: *"<<i<<endl;
		//LLTB.traverse();
		LLRBT_a.print();
		if(i==3)
			delElm = insElm;
	}
	cout<<"Deleteing fourth Element...."<<endl;
	LLRBT_a.deleteElement(delElm);
	LLRBT_a.traverse();
	return 0;
}
int genRand(const int min, const int max)
{
	return (rand()% max + min);
}
