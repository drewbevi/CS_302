#include "LLRBT.h"
//==========================================
//		IMPLEMENATION
//==========================================

//		CTOR

//=========================
template<class dataItem>
LeftLeaningRBTree<dataItem>::LeftLeaningRBTree()
{
	m_pRoot = nullptr;
}

//		INSERTION/ROTATION

//=========================
template<class dataItem>
LLTB_Node<dataItem>* LeftLeaningRBTree<dataItem>::rotateLeft(LLTB_Node<dataItem> *pNode)
{
	LLTB_Node<dataItem> *pTemp = pNode->getpRight();
	pNode->setpRight(pNode->getpLeft());
	pTemp->setpLeft(pNode);
	pTemp->setColor(pNode->getColor());
	pNode->setColor(true);
	return pTemp;
}
//=========================
template<class dataItem>
LLTB_Node<dataItem>* LeftLeaningRBTree<dataItem>::rotateRight(LLTB_Node<dataItem> *pNode)
{
	LLTB_Node<dataItem> *pTemp = pNode->getpLeft();
	pNode->setpRight(pNode->getpRight());
	pTemp->setpLeft(pNode);
	pTemp->setColor(pNode->getColor());
	pNode->setColor(true);
	return pTemp;
}
//=========================
template<class dataItem>
bool LeftLeaningRBTree<dataItem>::insert(dataItem &newData)
{
	LLTB_Node<dataItem>* pNew = new LLTB_Node<dataItem>(newData);
	m_pRoot = insertRec(m_pRoot, pNew);
	m_pRoot->setColor(false);
	return true;
}
//=========================
template<class dataItem>
LLTB_Node<dataItem>* LeftLeaningRBTree<dataItem>::insertRec(LLTB_Node<dataItem> *pNode, LLTB_Node<dataItem> *newNode)
{
	if(pNode == NULL)
	{
		//cout<<"test: inREC newNode()"<<endl;
		return newNode;
	}
	if(newNode->getItem() < pNode->getItem())
	{
		pNode->setpLeft(insertRec(pNode->getpLeft(),newNode));
	}
	else
	{
		pNode->setpRight(insertRec(pNode->getpRight(),newNode));
	}
	//cout<<"color change insREC"<<endl;
	if (isRed(pNode->getpRight()) && (!isRed(pNode->getpLeft())))
		pNode = rotateLeft(pNode);

	if (isRed(pNode->getpLeft()) && isRed(pNode->getpLeft()->getpLeft()))
		pNode = rotateRight(pNode);

	if (isRed(pNode->getpLeft()) && isRed(pNode->getpRight()))
		colorFlip(pNode);
	return pNode;
}

//		MOVE METHODS

//=========================
template<class dataItem>
LLTB_Node<dataItem>* LeftLeaningRBTree<dataItem>::moveRedLeft(LLTB_Node<dataItem> *pNode)
{
	colorFlip(pNode);
	if(NULL!=pNode->pRight && isRed(pNode->pRight->pLeft))
	{
		pNode->pRight =  rotateRight(pNode->pRight);
		pNode = rotateLeft(pNode);
		colorFlip(pNode);
	}
	return fixUp(pNode);
}
//=========================
template<class dataItem>
LLTB_Node<dataItem>* LeftLeaningRBTree<dataItem>::moveRedRight(LLTB_Node<dataItem> *pNode)
{
	colorFlip(pNode);
	if(NULL!=pNode->pLeft && isRed(pNode->pLeft->pLeft))
	{
		pNode = rotateRight(pNode);
		colorFlip(pNode);
	}
	return fixUp(pNode);
}

//		REMOVE METHODS

//=========================
template<class dataItem>
void LeftLeaningRBTree<dataItem>::deleteElement(const dataItem &delData)
{
	if(NULL != m_pRoot)
	{
		m_pRoot = deleteRec(m_pRoot, delData);
		if(NULL != m_pRoot)
		{
			m_pRoot->isRed = false;
		}
	}
}
//=========================
template<class dataItem>
LLTB_Node<dataItem>* LeftLeaningRBTree<dataItem>::deleteRec(LLTB_Node<dataItem> *pNode, const dataItem &delData)
{
	if (delData < pNode->data)
	{
		if (NULL != pNode->pLeft)
		{
			if ((!isRed(pNode->pLeft)) && (!isRed(pNode->pLeft->pLeft)))
			{
				pNode = moveRedLeft(pNode);
			}
			pNode->pLeft = deleteRec(pNode->pLeft, delData);
		}
	}
	else
	{
		if (isRed(pNode->pLeft))
		{
			pNode = rotateRight(pNode);
		}
		if ((delData == pNode->data) && (NULL == pNode->pRight))
		{
			delete pNode;
			return NULL;
		}
		if (NULL != pNode->pRight) 
		{
			if ((!isRed(pNode->pRight)) && (!isRed(pNode->pRight->pLeft)))
			{
				pNode = moveRedRight(pNode);
			}
			if (delData == pNode->data)
			{
				pNode->data    = findMin(pNode->pRight)->data;
				pNode->pRight = deleteMin(pNode->pRight);
			}
			else
			{
				pNode->pRight = deleteRec(pNode->pRight, delData);
			}
		}
	}
	return fixUp(pNode);
}

//		TRAVERSE METHODS

//=========================
template<class dataItem>
void LeftLeaningRBTree<dataItem>::traverse()
{
	if(NULL != m_pRoot)
	{
		dataItem prev = 0;
		traverseRec(m_pRoot,prev);
		cout<<endl;
	}
}
//=========================
template<class dataItem>
void LeftLeaningRBTree<dataItem>::traverseRec(LLTB_Node<dataItem> *pNode, dataItem &prev)
{
	if (NULL != pNode->pLeft) {
		traverseRec(pNode->pLeft, prev);
	}
	
	prev = pNode->data;
	cout<<"Value: "<<pNode->data<<endl;
		if(pNode->isRed==true)
			cout<<"Color: RED"<<endl;
		else
			cout<<"Color: BLACK"<<endl;

	if (NULL != pNode->pRight) {
		traverseRec(pNode->pRight, prev);
	}
}

//		EXTRA METHODS

//=========================
template<class dataItem>
LLTB_Node<dataItem>* LeftLeaningRBTree<dataItem>::fixUp(LLTB_Node<dataItem> *pNode)
{
	if(isRed(pNode->pRight))
	{
		pNode = rotateLeft(pNode);
	}
	if(isRed(pNode->pLeft) && isRed(pNode->pLeft->pLeft))
	{
		pNode = rotateRight(pNode);
	}
	if(isRed(pNode->pLeft) && isRed(pNode->pRight))
	{
		colorFlip(pNode);
	}
	return pNode;
}
//=========================
template<class dataItem>
LLTB_Node<dataItem>* LeftLeaningRBTree<dataItem>::findMin(LLTB_Node<dataItem> *pNode)
{
	while(NULL != pNode->pLeft)
	{
		pNode = pNode->pLeft;//b/c its left leaning the min value will be on the left most leaf
	}
	return pNode;
}
//=========================
template<class dataItem>
LLTB_Node<dataItem>* LeftLeaningRBTree<dataItem>::deleteMin(LLTB_Node<dataItem> *pNode)
{
	if(NULL == pNode->pLeft)
	{
		delete pNode;
		return NULL;
	}
	if((!isRed(pNode->pLeft)) && (!isRed(pNode->pLeft->pLeft)))
		pNode = moveRedLeft(pNode);
	pNode->pLeft = deleteMin(pNode->pLeft);
	return fixUp(pNode);
}
//=========================
template<class dataItem>
void LeftLeaningRBTree<dataItem>::colorFlip(LLTB_Node<dataItem> *pNode)
{
	pNode->isRed = !pNode->isRed;
	if(NULL != pNode->pLeft)
	{
		pNode->pLeft->isRed = !pNode->pLeft->isRed;
	}
	if(NULL != pNode->pRight)
	{
		pNode->pRight->isRed = !pNode->pRight->isRed;
	}
}
//=========================
template<class dataItem>
LLTB_Node<dataItem>* LeftLeaningRBTree<dataItem>::newNode(dataItem &newData)
{
	LLTB_Node<dataItem>* pNew = new LLTB_Node<dataItem>(newData);

	/*pNew->data = 0;
	pNew->isRed = true;
	pNew->pLeft = NULL;
	pNew->pRight = NULL;*/

	return pNew;
}

//=========================
template<class dataItem>
bool LeftLeaningRBTree<dataItem>::isRed(LLTB_Node<dataItem> *pNode)
{
	if(NULL != pNode)
	{
		return pNode->getColor() == true;
	}
	return false;
}
//=========================
template<class dataItem>
void LeftLeaningRBTree<dataItem>::print()
{
	cout<<"Value: "<<m_pRoot->data<<endl;
	if(m_pRoot->isRed==true)
		cout<<"Color: RED"<<endl;
	else
		cout<<"Color: BLACK"<<endl;

}
