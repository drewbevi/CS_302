#ifndef L_L_T_B_Node_
#define L_L_T_B_Node_
#include <iostream>
using namespace std;
template<class dataItem>
class LLTB_Node//  Node struct for items in class LeftLeaningRedBlack
{
	public:
		LLTB_Node<dataItem>();
		LLTB_Node(const dataItem &newData);
		dataItem getItem() const;
		void setItem( dataItem &newData);
		LLTB_Node<dataItem>* getpLeft() const;
		void setpLeft( LLTB_Node<dataItem> *newLeft);
		LLTB_Node<dataItem>* getpRight() const;
		void setpRight( LLTB_Node<dataItem> *newRight);
		bool getColor() const;//gets value isRed
		void setColor(bool newColor);//modifies value isRed
	//private:
		dataItem data;
		bool isRed;
		LLTB_Node<dataItem> *pLeft;
		LLTB_Node<dataItem> *pRight;
};
template<class dataItem>
LLTB_Node<dataItem>::LLTB_Node()
{
	data = 0;
	isRed = true;
	pLeft = NULL;
	pRight = NULL;
}
template<class dataItem>
LLTB_Node<dataItem>::LLTB_Node(const dataItem &newData)
{
	data = newData;
	pLeft = nullptr;
	pRight = nullptr;
	isRed = true;
}
template<class dataItem>
dataItem LLTB_Node<dataItem>::getItem() const
{
	return data;
}
template<class dataItem>
void LLTB_Node<dataItem>::setItem( dataItem &newData)
{
	data = newData;
}
template<class dataItem>
LLTB_Node<dataItem>* LLTB_Node<dataItem>::getpLeft() const
{
	return pLeft;
}
template<class dataItem>
void LLTB_Node<dataItem>::setpLeft( LLTB_Node<dataItem> *newLeft)
{
	pLeft = newLeft;
}
template<class dataItem>
LLTB_Node<dataItem>* LLTB_Node<dataItem>::getpRight() const
{
	return pRight;
}
template<class dataItem>
void LLTB_Node<dataItem>::setpRight( LLTB_Node<dataItem> *newRight)
{
	pRight = newRight;
}
template<class dataItem>
bool LLTB_Node<dataItem>::getColor() const
{
	return isRed;
}
template<class dataItem>
void LLTB_Node<dataItem>::setColor(bool newColor)
{
	isRed = newColor;//T=Red F=Black
}
#endif
