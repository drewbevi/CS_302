#ifndef L_L_R_B_T_
#define L_L_R_B_T_
#include "LLTBNode.h"
#include <iostream>
using namespace std;
template<class dataItem>
class LeftLeaningRBTree
{
	private:
		LLTB_Node<dataItem> *m_pRoot;
	public:
		//  Ctors
		LeftLeaningRBTree();

		//  Insertion/Rotation
		LLTB_Node<dataItem>* rotateLeft(LLTB_Node<dataItem> *pNode);
		LLTB_Node<dataItem>* rotateRight(LLTB_Node<dataItem> *pNode);
		bool insert(dataItem &newData);
		LLTB_Node<dataItem>* insertRec(LLTB_Node<dataItem> *pNode, LLTB_Node<dataItem> *newNode);

		//  Move methods
		LLTB_Node<dataItem>* moveRedRight(LLTB_Node<dataItem> *pNode);//check
		LLTB_Node<dataItem>* moveRedLeft(LLTB_Node<dataItem> *pNode);
		
		//  Remove methods
		void deleteElement(const dataItem &delData);
		LLTB_Node<dataItem>* deleteRec(LLTB_Node<dataItem> *pNode,const dataItem &delData );

		//  Traverse methods
		void traverse();
		void traverseRec(LLTB_Node<dataItem> *mpNode, dataItem &prev);//print method
		//  Extra methods
		LLTB_Node<dataItem>* fixUp(LLTB_Node<dataItem> *pNode);//check
		LLTB_Node<dataItem>* findMin(LLTB_Node<dataItem> *pNode);//check
		LLTB_Node<dataItem>* deleteMin(LLTB_Node<dataItem> *pNode);
		void colorFlip(LLTB_Node<dataItem> *pNode);//check
		LLTB_Node<dataItem>* newNode(dataItem &newData);
		bool isRed(LLTB_Node<dataItem> *pNode);
		void print();
};
#endif
