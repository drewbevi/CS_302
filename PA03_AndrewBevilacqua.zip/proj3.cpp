#include <cstdlib>
#include <ctime>
#include <iostream>
#include <fstream>
#include <string>
#include "BinarySearchTree.h"
using namespace std;
int genRand(const int min, const int max);
int main()
{
	int min = 0;
	int max = 199;
	int randNum =0;
	ofstream outfile;
	string fileName= "outfile.txt";
	outfile.open(fileName);
	BinarySearchTree<int> binaryTree;
	srand(time(NULL));
	for (int i = 0; i < 99; i++)
	{
		randNum = genRand(min,max);
		outfile<< randNum<<endl;
		binaryTree.add(randNum);
	}
	outfile.close();
	cout<<"Height of Tree: "<<binaryTree.getHeight()<<endl;
	binaryTree.inorder();
	binaryTree.preorder();
	binaryTree.postorder();
	return 0;
}

int genRand(const int min, const int max)
{
	return (rand()% max + min);
}
