#ifndef BINARY_NODE_
#define BINARY _NODE_
#include <iostream>
//#include <memory>
using namespace std;
template<typename ItemType>
class BinaryNode
{
	public:
		BinaryNode();
		BinaryNode(const ItemType & iTem);
		ItemType getItem() const;
		void setLeft(BinaryNode<ItemType> *left);
		void setRight(BinaryNode<ItemType> *right);
 		BinaryNode<ItemType>* getLeft() const;
		BinaryNode<ItemType>* getRight() const;
	private:
		ItemType item;
		BinaryNode<ItemType> *leftPtr;
		BinaryNode<ItemType> *rightPtr;
};
template<class ItemType>
BinaryNode<ItemType>::BinaryNode():item(0), leftPtr(nullptr), rightPtr(nullptr)
{
}
template<class ItemType>
BinaryNode<ItemType>::BinaryNode(const ItemType & iTem):item(iTem), leftPtr(nullptr), rightPtr(nullptr)
{
}
template<class ItemType>
ItemType BinaryNode<ItemType>:: getItem() const
{
	return item;
}
template<class ItemType>
void BinaryNode<ItemType>:: setLeft(BinaryNode<ItemType> * left)
{
	leftPtr = left;
}
template<class ItemType>
void BinaryNode<ItemType>:: setRight(BinaryNode<ItemType> * right)
{
	rightPtr = right;
}
template<class ItemType>
BinaryNode<ItemType>* BinaryNode<ItemType>::getLeft() const
{
	return leftPtr;
}
template<class ItemType>
BinaryNode<ItemType>* BinaryNode<ItemType>::getRight() const
{
	return rightPtr;
}
#endif

