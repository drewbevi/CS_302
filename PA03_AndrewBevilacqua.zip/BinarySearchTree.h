#ifndef BINARY_SEARCH_TREE_
#define BINARY_SEARCH_TREE_
#include "BinaryNode.h"
#include <iostream>
#include <algorithm>
#include<memory>
using namespace std;
template<class ItemType>
class BinarySearchTree: public BinaryNode<ItemType>
{
	private:
		BinaryNode<ItemType> *rootPtr;
	protected:
		BinaryNode<ItemType>* placeNode(BinaryNode<ItemType> *subTreePtr, BinaryNode<ItemType> *newNode);
		int getHeightHelper(BinaryNode<ItemType> *subTreePtr) const;
		void preorderTraverse(BinaryNode<ItemType> *subTreePtr) const;//root, then left,  then right
		void inorderTraverse(BinaryNode<ItemType> *subTreePtr) const;//traverse Left,then root, then traverse right
		void postorderTraverse(BinaryNode<ItemType> *subTreePtr) const;// left, then right, then root
	public:
		BinarySearchTree();
		int getHeight() const;
		bool add(const ItemType& newEntry);
		void preorder() const;
		void inorder()const;//these are used to display the pre,post,and inorder Traversals
		void postorder()const;
		
};
//===================================================================================================
//IMPLEMETATION
//===================================================================================================
template<class ItemType>//ctor
BinarySearchTree<ItemType>:: BinarySearchTree(): rootPtr(nullptr)
{	
}


template<class ItemType>
BinaryNode<ItemType>* BinarySearchTree<ItemType>:: placeNode(BinaryNode<ItemType> *subTreePtr, BinaryNode<ItemType> *newNodePtr)
{
	BinaryNode<ItemType> *tempPtr = nullptr;
	if(subTreePtr == nullptr)
	{
		return newNodePtr;
	}
	else if(subTreePtr->getItem() > newNodePtr->getItem())
	{
		tempPtr = placeNode(subTreePtr->getLeft(),newNodePtr);
		subTreePtr->setLeft(tempPtr);
	}
	else
	{
		tempPtr = placeNode(subTreePtr->getRight(), newNodePtr);
		subTreePtr->setRight(tempPtr);
	}
	return subTreePtr;
}
template<class ItemType>
int BinarySearchTree<ItemType>:: getHeightHelper(BinaryNode<ItemType> *subTreePtr) const
{
	if(subTreePtr == nullptr)
		return 0;
	else
		return (1 + max(getHeightHelper(subTreePtr -> getLeft()),getHeightHelper(subTreePtr -> getRight())));
}


template<class ItemType>
bool BinarySearchTree<ItemType>:: add(const ItemType & newItem)
{
	BinaryNode<ItemType>* newNodePtr = new BinaryNode<ItemType>(newItem);
	rootPtr = placeNode(rootPtr,newNodePtr);
	return true;
}
template<class ItemType>
int BinarySearchTree<ItemType>:: getHeight() const
{
	int height = getHeightHelper(rootPtr);
	return height;
}
template<class ItemType>
void BinarySearchTree<ItemType>:: preorderTraverse(BinaryNode<ItemType> *subTreePtr) const
{
	if(subTreePtr == nullptr)//checks to see if tree/Node is empty
		return;
	cout<< subTreePtr->getItem()<< " ";
	preorderTraverse(subTreePtr->getLeft());
	preorderTraverse(subTreePtr->getRight());
}
template<class ItemType>
void BinarySearchTree<ItemType>:: inorderTraverse(BinaryNode<ItemType> *subTreePtr) const
{
	if(subTreePtr == nullptr)//checks to see if tree/Node is empty
		return;
	preorderTraverse(subTreePtr->getLeft());
	cout<< subTreePtr->getItem()<< " ";
	preorderTraverse(subTreePtr->getRight());
}
template<class ItemType>
void BinarySearchTree<ItemType>:: postorderTraverse(BinaryNode<ItemType> *subTreePtr) const
{
	if(subTreePtr == nullptr)//checks to see if tree/Node is empty
		return;
	preorderTraverse(subTreePtr->getLeft());
	preorderTraverse(subTreePtr->getRight());
	cout<< subTreePtr->getItem()<< " ";
}
template<class ItemType>
void BinarySearchTree<ItemType>::preorder() const
{
	cout<<"Preorder of Tree: ";
	preorderTraverse(rootPtr);
	cout<<endl;
}
template<class ItemType>
void BinarySearchTree<ItemType>::inorder() const
{
	cout<<"Inorder of Tree: ";
	inorderTraverse(rootPtr);	
	cout<<endl;
}
template<class ItemType>
void BinarySearchTree<ItemType>::postorder() const
{
	cout<<"Postorder of Tree: ";
	postorderTraverse(rootPtr);
	cout<< endl;
}
#endif
