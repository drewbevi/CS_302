#include <cstdlib>
#include <ctime>
#include <iostream>
#include <fstream>
#include <string>
#include <ostream>
using namespace std;
int genRand(const int min, const int max);

int main()
{
	int min = 0;
	int max = 1000000;
	int count =0;
	srand(time(NULL));
	string filename;
	ofstream outfile;
	cout<<"fileName??"<<endl;
	cin>>filename;
	cout<<"count?(1000,10000,100000)"<<endl;
	cin>>count;
	outfile.open(filename.c_str());
	for (int i = 0; i < count; i++)
	{
		outfile << genRand(min, max) << endl;
	}
	outfile.close();
	return 0;
}

int genRand(const int min, const int max)
{
	return (rand()% max + min);
}
