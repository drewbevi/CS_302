#ifndef BUBBLESORT_H
#define BUBBLESORT_H
#include <iostream>
#include <fstream>
#include <string>
using namespace std;
class bubbleSort
{
	public:
		bubbleSort(const int max);
		void readFromFile(const string &fileName);
		void writeToFile(const string &fileName);
		bool sort(int &comp,int &swaps);
	private:
		int *array;
		int maxSize;
		int size;
};
bubbleSort::bubbleSort(const int max)
{
	array = new int[max];
	size = 0;
	maxSize = max; 
}
void bubbleSort::readFromFile(const string &fileName)
{
	ifstream file;
	file.open(fileName.c_str());
	for(int i = 0; i < maxSize; i++)
	{
		
		file >> array[i];
		size++;
	}
}
void bubbleSort::writeToFile(const string &fileName)
{
	ofstream file;
	file.open(fileName.c_str());
	for(int i = 0; i < size; i++)
	{
		file << array[i] << endl;
	}
}
bool bubbleSort::sort(int &comp,int &swaps)
{
	bool swapped = false;
	for(int i = 0; i <size-1;i++)
	{
		for(int j = 0; j<size-i-1;j++)
		{
			comp++;
			if(array[j]>array[j+1])
			{
				int temp = array[j];
				array[j] = array[i];
				array[i] = temp;
				swapped = true;
				++swaps;
			}
		}
		if(swapped==false)
			break;
	}
	return swapped;
}
#endif
