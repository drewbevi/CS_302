#ifndef MERGESORT_H
#define MERGESORT_H
#include <iostream>
#include <fstream>
#include <string>
using namespace std;
class quickSort
{
	public:
		quickSort(const int max);
		void readFromFile(const string &fileName);
		void writeToFile(const string &fileName);
		void sort(int *arr,int s, int e,int &comp, int &swaps);
		int partition(int *arr,int s, int e,int &comps, int &swaps);
		int getSize()const;
		int* getArray()const;
	private:
		int *array;
		int size;
		int maxSize;
};
quickSort::quickSort(const int max)
{
	array = new int[max];
	size = 0;
	maxSize = max; 
}
void quickSort::readFromFile(const string &fileName)
{
	ifstream file;
	file.open(fileName.c_str());
	for(int i = 0; i < maxSize; i++)
	{
		
		file >> array[i];
		size++;
	}
}
void quickSort::writeToFile(const string &fileName)
{
	ofstream file;
	file.open(fileName.c_str());
	for(int i = 0; i < size; i++)
	{
		file << array[i] << endl;
	}
}		
int quickSort::partition(int *arr,int s, int e,int &comp,int &swaps)
{
	int pivot = arr[e];
	int index = s;
	int t=0;
	for(int i = s; i<e;i++)
	{
		++comp;
		if(arr[i]<=pivot)
		{
			t = arr[i];
			arr[i]=arr[index];
			arr[index]=t;
			index++;
			++swaps;
		}
	}
	t = arr[e];
	arr[e] = arr[index];
	arr[index] = t;
	++swaps;
	return index;

}
void quickSort::sort(int *arr,int s, int e,int &comp, int &swaps)
{
	if(s<e)
	{
		int pivotIndex = partition(arr,s,e,comp,swaps);
		sort(arr,s,pivotIndex-1,comp,swaps);
		sort(arr,pivotIndex+1,e,comp,swaps);
	}
}
int quickSort::getSize()const
{
	return size;
}
int* quickSort::getArray()const
{
	return array;
}
#endif
