#include <iostream>
#include <time.h>
//#include <string>
#include "bubbleSort.h"
#include "quickSort.h"
int main()
{
	//Bubble Sort
	cout<<"===============Bubble Sort==============="<<endl;
	int comp = 0, swaps = 0;
	clock_t t;
	string fileName;
	bubbleSort bubbles(1000);
	//cout<<"Enter File name for Bubble Sort:"<<endl;
	//cin>>fileName;
	bubbles.readFromFile("rand_1000.txt");
	t = clock();
	bubbles.sort(comp,swaps);
	t=clock()-t;
	cout<<"Seconds: "<< t <<endl;
	cout<<"Comparisons: "<< comp <<endl;
	cout<<"Swaps: "<< swaps <<endl;

	//Quick Sort
	cout<<"===============Quick Sort==============="<<endl;
	int compQ = 0, swapsQ = 0;
	clock_t tQ;
	string fileNameQ;
	quickSort quickie(1000);
	//cout<<"Enter File name for Quick Sort:"<<endl;
	//cin>>fileNameQ;

	quickie.readFromFile("rand_1000.txt");
	tQ = clock();
	quickie.sort(quickie.getArray(),0,(quickie.getSize()-1),compQ,swapsQ);
	tQ=clock()-tQ;
	cout<<"Seconds: "<< tQ <<endl;
	cout<<"Comparisons: "<< compQ <<endl;
	cout<<"Swaps: "<< swapsQ <<endl;
	//cout<<"Output file?"<<endl;
	//cin>>fileNameQ;
	//quickie.writeToFile(fileNameQ);
	return 0;
}
