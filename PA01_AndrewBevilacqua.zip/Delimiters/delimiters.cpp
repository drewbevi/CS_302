//--------------------------------------------------------------------
//
//   delimiters.cpp
//
//--------------------------------------------------------------------

#include <iostream>
#include <string.h>
#include "StackLinked.h"
using namespace std;
//--------------------------------------------------------------------

bool delimitersOk ( const string &expression );

//--------------------------------------------------------------------

int main()
{
    /*string inputLine;            // Input line
    char   ch;                   // Holding pen for input chars

    cout << "This program checks for properly matched delimiters."
         << endl;

    while( cin )
    {
        cout << "Enter delimited expression (<EOF> to quit) : "
             << endl;

        // Read in one line
        inputLine = "";
        cin.get(ch);
        while( cin && ch != '\n' )
        {
            inputLine = inputLine + ch;
            cin.get(ch);
        }

        if( ! cin )              // Reached EOF: stop processing
            break;
    
        if ( delimitersOk (inputLine) )
            cout << "Valid" << endl;
        else
            cout << "Invalid" << endl;
    }*/
	cout<<"Exercise 2: Assignment 2"<<endl;
	cout<<"1.[{<(()>}] "<< (delimitersOk("[{<(()>}]")?"Valid":"Invalid")<<endl;
	cout<<"2.(CS302) "<< (delimitersOk("(CS302)")?"Valid":"Invalid")<<endl;
	cout<<"3. <<><>"<< (delimitersOk("<<><>")?"Valid":"Invalid")<<endl;
	cout<<"4.[{]} "<< (delimitersOk("[{]}")?"Valid":"Invalid")<<endl;
	cout<<"5.() "<< (delimitersOk("()")?"Valid":"Invalid")<<endl;

    return 0;
}

//--------------------------------------------------------------------
// delimitersOk: the function that students must implement for 
//    Programming Exercise 3.
// Note: we used the term "braces" to describe '[' and ']'. It would
//    have been better to use the term "brackets". The program can be
//    easily modified to process any set of matching delimiters.
//--------------------------------------------------------------------

// Insert your delimitersOk function below


bool delimitersOk ( const string &expression )
{
	StackLinked<char> stack;
	int len = expression.length();
	for(int i = 0;i<len;i++)
	{
		switch(expression[i])//Switch statement to detemine which delimiter is what/if they match
		{
			//Opening delimeter
			case '(':
				stack.push(expression[i]);
				break;
			case '<':
				stack.push(expression[i]);
				break;
			case '{':
				stack.push(expression[i]);
				break;
			case '[':
				stack.push(expression[i]);
				break;
			//Closeing delimiter
			case ')':
				if(stack.pop()!='(')//if statements checks to see if it has a pair
					return false;
				break;
			case '>':
				if(stack.pop()!='<')
					return false;
				break;
			case '}':
				if(stack.pop()!='{')
					return false;
				break;
			case ']':
				if(stack.pop()!='[')
					return false;
				break;
		}
	}
	return stack.isEmpty();
}

