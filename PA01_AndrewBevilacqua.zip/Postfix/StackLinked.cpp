

/*
-------------------------------------------------------------------------------------
Original StackLinked.cpp, throughout the debugging process I ended up placeing all implementaion in the StackLinked.h
-------------------------------------------------------------------------------------
*/


#include "StackLinked.h"
template<class DataType>
StackLinked<DataType>::StackLinked(int maxNumber)//def ctor 
{
	top=NULL;//makes the top value in a stack NULL, makes stack size = MAX_STACK_SIZE
}
template<class DataType>
StackLinked<DataType>::StackLinked(const StackLinked& other)//copy ctor
{
	StackNode *currTop = top;
	StackNode *otherTop = other.top;
	while(otherTop != NULL)
	{
		currTop = new StackNode(otherTop->dataItem, otherTop->next);
		currTop = currTop->next;
		otherTop = otherTop->next;
	}
}
template<class DataType>
StackLinked<DataType> & StackLinked<DataType> :: operator=(const StackLinked& other)//copy ctor?
{
	if(this != other)
	{
		clear();//clears the soon to be modified stack
		this(other);
	}
	return *this;
}
template<class DataType>
StackLinked<DataType>::~StackLinked()//destructor
{
	clear();//clears the whole stack, doubles as a destructor
}
template<class DataType>
void StackLinked<DataType>::push(const DataType& newDataItem) throw (logic_error)//adds and dataitem to the top of the stack node, pushinge preceding nodes down
{
	if(isFull())
	{
		throw logic_error("Cannot push a dataitem into a full stack.");
	}
	else
	{
	
		top = new StackNode(newDataItem, top);//pushes a SINGLE value into the top of the stack, uses the StackNode Ctor
	}
}
template<class DataType>
DataType StackLinked<DataType>::pop() throw (logic_error)//removes top dataItem and pushes stack nodes up one
{
	if(isEmpty())
	{
		throw logic_error("Cannot pop a dataitem from an empty stack.");
	}
	else
	{
		DataType topData = top->dataItem;//creates a datatype equal to the dataitem in the top of the stack
		top--;//pushes the top dataitem of the stack to the next 
		return topData;
	}
}
template<class DataType>
void StackLinked<DataType>::clear()
{
	StackNode *remove = NULL;//creates a stacknode that will be used to delete a the current node    TEST: removing the pointer
	StackNode *curr = top;//points to the top node in the stack
	while(curr!=NULL)
	{
		remove = curr;//copys the current node to the removeable node
		curr = curr->next;//pushes the dataitem 
		delete remove;
	}
}
template<class DataType>
bool StackLinked<DataType>::isEmpty() const
{
	return top != NULL;//if the top value is null then there are no dataitems present
}
template<class DataType>
bool StackLinked<DataType>::isFull() const
{
	return false;//Stack cannot be full, no max size
	/*int count=0;//count to keep track of dataItems
	StackNode *curr = top;//local variable
	while(count!=7)//while the stack does not = the max size (0-7)
	{
		if(curr==NULL)//if the top most value is NULL then the Stack is not full
		{
			return false;
		}
		else
		{
			curr = curr->next;//shifts to the next node in the stack
			count++;
		}
	}
	return true;*/  //This is a good bit of code but doesnt apply to a stack
}
template<class DataType>
void StackLinked<DataType>::showStructure() const
{
	if(isEmpty())
	{
		cout<<"The stack is empty."<<endl;
	}
	else
	{
		StackNode *curr = top;//locak var
		while(curr!=NULL)
		{
			cout<<curr->dataItem<<" ";//prints the dataItem in the stack
			curr=curr->next;
		}
	}
}
