//--------------------------------------------------------------------
//
//  StackArray.h
// 
//  Class declaration for the array implementation of the Stack ADT
//
//--------------------------------------------------------------------

#ifndef STACKARRAY_H
#define STACKARRAY_H

#include <stdexcept>
#include <iostream>

using namespace std;

#include "Stack.h"
//MAX_STACK_SIZE = 8

template <typename DataType>
class StackLinked : public Stack<DataType>
{

  public:

    StackLinked(int maxNumber = Stack<DataType>::MAX_STACK_SIZE);//def ctor
    StackLinked(const StackLinked& other);//copy ctor
    StackLinked& operator=(const StackLinked& other);//insertion operator
    ~StackLinked();//destructor

    void push(const DataType& newDataItem) throw (logic_error);//pushes data to TOP of stack
    DataType pop() throw (logic_error);//pops top data value and moves all data up

    void clear();//clears stack

    bool isEmpty() const;//checks if the stack is empty
    bool isFull() const;//checks if stack is full/!empty

    void showStructure() const;//prints stack

  private:

    class StackNode 
    {
      public:
	StackNode(const DataType& nodeData, StackNode* nextPtr);

	DataType dataItem;
	StackNode* next;//data memeber of StackNode(private or public?)
    };

    StackNode* top;//private data  is part of stacklinked class
};



/*------------------------------------------------------
		Implementation
--------------------------------------------------------*/
template<class DataType>
StackLinked<DataType>::StackLinked(int maxNumber)//def ctor 
{
	top=nullptr;//makes the top value in a stack NULL, makes stack size = MAX_STACK_SIZE
}
template<class DataType>
StackLinked<DataType>::StackLinked(const StackLinked& other)//copy ctor
{
	StackNode *currTop = top;
	StackNode *otherTop = other.top;
	while(otherTop != nullptr)
	{
		currTop = new StackNode(otherTop->dataItem, otherTop->next);
		currTop = currTop->next;
		otherTop = otherTop->next;
	}
}
template<class DataType>
StackLinked<DataType> & StackLinked<DataType> :: operator=(const StackLinked& other)//copy ctor?
{
	if(this != other)
	{
		clear();//clears the soon to be modified stack
		this(other);
	}
	return *this;
}
template<class DataType>
StackLinked<DataType>::~StackLinked()//destructor
{
	clear();//clears the whole stack, doubles as a destructor
}
template<class DataType>
void StackLinked<DataType>::push(const DataType & newDataItem) throw (logic_error)//adds and dataitem to the top of the stack node, pushinge preceding nodes down
{
	if(isFull())
	{
		throw logic_error("Cannot push a dataitem into a full stack.");
	}
	else
	{
	
		top = new StackNode(newDataItem, top);//pushes a SINGLE value into the top of the stack, uses the StackNode Ctor
	}
}
template<class DataType>
DataType StackLinked<DataType>::pop() throw (logic_error)//removes top dataItem and pushes stack nodes up one
{
	if(isEmpty())
	{
		throw logic_error("Cannot pop a dataitem from an empty stack.");
	}
	else
	{
		DataType topData = top->dataItem;//creates a datatype equal to the dataitem in the top of the stack
		top = top->next;
		//top--;//pushes the top dataitem of the stack to the next 
		return topData;
	}
}
template<class DataType>
void StackLinked<DataType>::clear()
{
	StackNode *remove = nullptr;//creates a stacknode that will be used to delete a the current node    TEST: removing the pointer
	StackNode *curr = top;//points to the top node in the stack
	while(curr!=nullptr)
	{
		remove = curr;//copys the current node to the removeable node
		curr = curr->next;//pushes the dataitem 
		delete remove;
	}
}
template<class DataType>
bool StackLinked<DataType>::isEmpty() const
{
	return top == nullptr;//if the top value is null then there are no dataitems present
}
template<class DataType>
bool StackLinked<DataType>::isFull() const
{
	return false;//Stack cannot be full, no max size


	/*int count=0;//count to keep track of dataItems
	StackNode *curr = top;//local variable
	while(count!=7)//while the stack does not = the max size (0-7)
	{
		if(curr==NULL)//if the top most value is NULL then the Stack is not full
		{
			return false;
		}
		else
		{
			curr = curr->next;//shifts to the next node in the stack
			count++;
		}
	}
	return true;*/  //This is a good bit of code but doesnt apply to a stack


}
template<class DataType>
void StackLinked<DataType>::showStructure() const
{
	if(isEmpty())
	{
		cout<<"The stack is empty."<<endl;
	}
	else
	{
		StackNode *curr = top;//locak var
		while(curr!=nullptr)
		{
			cout<<curr->dataItem<<" ";//prints the dataItem in the stack
			curr=curr->next;
		}
	}
}
template<class DataType>
StackLinked<DataType>::StackNode::StackNode(const DataType &nodeData, StackNode *nextPtr)
{
	dataItem=nodeData;
	next=nextPtr;
}
#endif		//#ifndef STACKARRAY_H
