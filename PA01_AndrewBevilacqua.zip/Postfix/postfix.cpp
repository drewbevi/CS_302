#include <iostream>
#include <string>
#include <math.h>
#include "StackLinked.h"
float Evaluate(string postfix, StackLinked<float> & stack);
float Calculate(const float num1, const float num2, const char sign)throw (logic_error);
int main()
{
	StackLinked<float> stack;
	cout<<"Exercise 1: Assignment 1"<<endl;
	cout<<"Infix form: (3+4)*(5/2) ---> Postfix form: 34+52/* ---> Evaluated: "<<Evaluate("56+43/*",stack)<<endl;
	cout<<"Exercise 1: Assignment 2"<<endl;
	cout<<"1.Infix form: (7/5)/(4*5) ---> Postfix form: 75/45*/ ---> Evaluated: "<<Evaluate("75/45*/",stack)<<endl;
	cout<<"2.Infix form: (9^2)+(9/7) ---> Postfix form: 92^97/+ ---> Evaluated: "<<Evaluate("92^97/+",stack)<<endl;
	cout<<"3.Infix form: (3-2)+(3-4) ---> Postfix form: 32-34-+ ---> Evaluated: "<<Evaluate("32-34-+",stack)<<endl;
	cout<<"4.Infix form: (1/2)*(3/4) ---> Postfix form: 12/34/* ---> Evaluated: "<<Evaluate("12/34/*",stack)<<endl;
	cout<<"5.Infix form: (2^2)*(3^3) ---> Postfix form: 22^33^* ---> Evaluated: "<<Evaluate("22^33^*",stack)<<endl;
}
float Evaluate(string postfix, StackLinked<float> & stack)
{
	stack.clear();//clears stack just in case
	int i=0;
	while(postfix[i]!='\0')//while the postfix is not empty the function will continue
	{
		if(isdigit(postfix[i]))//checks to see if the current element is a digit
		{
			stack.push(postfix[i]-'0');
		}
		else
		{
			float num1=  stack.pop();
			float num2= stack.pop();
			float result = Calculate(num1,num2,postfix[i]);
			stack.push(result);
		}
		++i;
	}
	return stack.pop();
}
float Calculate(const float num1, const float num2, const char sign)throw (logic_error)
{
	switch(sign)//Switch statement to determine what sign to implement
	{
		case '+':
			return num2 + num1;
		case '-':
			return num2 - num1;
		case '*':
			return num2 * num1;
		case '/':
			return num2 / num1;
		case '^':
			return pow(num2,num1);
		default :
			throw logic_error("Invalid operator.");
	}
}
