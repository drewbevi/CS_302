#include <iostream>
#include <algorithm>
#include <vector>
#define V 5
#define MAX_VAL 100000	//max the sales rep can travel is 46(mpg not calc)
using namespace std;
int TSP(int matrix[][V], int src);
void findCity(int city,int cost, int matrix[][V]);
int main()
{
	//enum cities{Reno, SF, saltLake, Seattle, lasVegas};
	int a = 0;
	int matrix[][V] = {	{0,40,70,110,70},	//Reno -> dest.
				{40,0,0,12,80},		//SF -> dest.
				{70,0,0,120,50},	//saltLake -> dest.
				{110,120,120,0,0},	//Seattle -> dest.
				{70,80,50,0,0} };	//lasVegas -> dest.
	int min_cost = TSP(matrix,0);
	cout<<"**NOTE: Distance between cities is not accurate**"<<endl<<endl;
	cout<< "The minimum cost for the salesman is: "<<min_cost<<" miles"<<endl;
	cout<< "With an average of 40 miles per gallon the salesman must travel: "<< min_cost/40<<" MPG"<<endl;
	cout<< "Current path:" <<endl;
	cout<< "Reno -->SF-->Las Vegas-->Salt Lake-->Seattle-->Reno"<<endl;
	return 0;
}
int TSP(int matrix[][V],int src)
{
	vector<int> vector;//vector of vertecies  I could just use an array
	int min_cost = MAX_VAL;//Min cost starts out as the max cost and then changed throughout
	
	for(int i=0; i<V;i++)
	{
		if(i!=src)
			vector.push_back(i);
	}
	do
	{
		int curr_cost = 0;
		int a = src;//stores the element of the min path
		for(int i=0; i < vector.size(); i++)
		{
			curr_cost += matrix[a][vector[i]];
			a = vector[i];
		}
		curr_cost += matrix[a][src];
		min_cost = min(min_cost,curr_cost);
	} while(next_permutation(vector.begin(), vector.end()) );
	return min_cost;
}
void findCities(int city,int cost, int matrix[][V])
{
	int visited[V], cityElm = 0;
	visited[city] = 1;
	cout<<city<<"-->";
	//cityElm = least(city);
	if(cityElm == MAX_VAL)
	{
		cityElm = 0;
		cout<<cityElm;
		cost += matrix[city][cityElm];
		return;
	}
	findCities(cityElm,cost,matrix);
}

