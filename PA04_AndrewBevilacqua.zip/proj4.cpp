#include <iostream>
//#include <vector>
#include <algorithm>
#include <fstream>
using namespace std; 
const int MAX_VAL = 100;
const int MIN_VAL = 1;
int genRand(const int min, const int max);
int findVecMean(vector<int> &V);
void print(const vector<int> &V);
void outputToFile(vector<int> &V,ofstream &outFile);
int main() 
{
	//Exercise 1.1 create a random 100 integer heap

	// Initializing a vector 
	vector<int> v1;
	// Converting vector into a heap using make_heap() 
	for(int i = MIN_VAL;i<=MAX_VAL;i++)
	{
		v1.push_back(genRand(MIN_VAL,MAX_VAL)); 
	}
	if(!is_heap(v1.begin(),v1.end()))
		make_heap(v1.begin(),v1.end());
	else
		cout<<"Error, heap not created."<<endl;
	cout<<"100 random integer heap:"<<endl<<"===================="<<endl;
	print(v1);

	//Exercise 1.2 find mean of heap and push value

	int mean = findVecMean(v1);
	v1.push_back(mean);
	push_heap(v1.begin(),v1.end());
	cout<<"Heap with mean ( "<<mean<<" ) value added:"<<endl<<"===================="<<endl;
	print(v1);

	//Exercise 1.3 delete Max element of heap
	
	cout<<"The max element in the heap is: "<<v1.front()<<endl;
	pop_heap(v1.begin(),v1.end());
	v1.pop_back();
	cout<<"The max element in the heap after pop is: "<<v1.front()<<endl;

	//Exercise 1.4 sort heap and export to .txt file
	
	ofstream outFile;
	outFile.open("outputProj4.txt");
	sort_heap(v1.begin(),v1.end());
	cout<<"Sorted heap: "<<endl<<"===================="<<endl;
	print(v1);
	outFile.close();
	return 0;
}
int genRand(const int min, const int max)
{
	return (rand()% max + min);
}
void print(const vector<int> &V)
{
	for(int i = MIN_VAL;i<=V.size();i++)
	{
		cout<<V[i]<<endl;
	}
	cout<<endl;
}
int findVecMean(vector<int> &V)
{
	int mean = 0;
	for(int i = 0;i < V.size();i++)
	{
		mean += V[i];
	}
	return mean / V.size();
}
void outputToFile(vector<int> &V,ofstream &outFile)
{
	//outFile.open("outputProj4.txt");
	for(int i = MIN_VAL;i<=V.size();i++)
	{
		outFile<<V[i]<<endl;
	}
	//outFile.close();
}
